Contents of 3 folders:

	all/
		all_pdb_ids_no_dupes.txt 		-> All unique pdb id codes in the online PDB database (GOOD).
		all_pdb_ids_WITH_DUPES.txt		-> Unfiltered list of all pdb codes, containing duplicates.
		pdb_ids_authors_all_WITH_DUPES.txt	-> Raw list from the PDB online database, lots of junk info. 

	ras-family/
		all_pdb_ids_minus_ras.txt		-> A listing of all pdb id codes sans those belonging to the ras family (based on NCI listing).
		all_pdb_ids_no_dupes.txt		-> All unique pdb id codes in the online PDB database (GOOD).
		online_db_ras_ids.txt			-> A listing of ras protein family members from PDB online database.
		ras_pdb_ids.txt				-> A listing of ras protein family members based on NCI dataset.

	wd40-family/
		all_pdb_ids_no_dupes.txt		-> All unique pdb id codes in the online PDB database (GOOD).
		all_pdbs_minus_wd40.txt			-> A listing of all pdb id codes sans those belonging to the ras family (based on online PDB database listing).
		wd40_pbd_ids.txt			-> A listing of the wd40 protein family members based on PDB online dataset.